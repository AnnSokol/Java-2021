package com.ann.sokol.controller.exception;

public class PersonAlreadyExistException extends Exception {

    public PersonAlreadyExistException(String message) {
        super(message);
    }
}
