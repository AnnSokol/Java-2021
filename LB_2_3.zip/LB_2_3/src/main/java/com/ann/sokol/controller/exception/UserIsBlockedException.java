package com.ann.sokol.controller.exception;

public class UserIsBlockedException extends Exception {

    public UserIsBlockedException(String message) {
        super(message);
    }
}
