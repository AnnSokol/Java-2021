package com.ann.sokol.controller.exception;

public class AuthenticationException extends Exception {

    public AuthenticationException(String message) {
        super(message);
    }
}
