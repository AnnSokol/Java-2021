package com.ann.sokol.controller.exception;

public class NonExistentSizeException extends Exception {

    public NonExistentSizeException(String message) {
        super(message);
    }
}
