package com.ann.sokol.controller.exception;

public class PriceIsNegativeNumberException extends Exception {

    public PriceIsNegativeNumberException(String message) {
        super(message);
    }
}
