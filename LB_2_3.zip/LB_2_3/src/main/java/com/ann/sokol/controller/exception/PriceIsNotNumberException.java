package com.ann.sokol.controller.exception;

public class PriceIsNotNumberException extends Exception {

    public PriceIsNotNumberException(String message) {
        super(message);
    }
}
