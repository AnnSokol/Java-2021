package com.ann.sokol.controller.exception;

public class PasswordsNotMatchException extends Exception {

    public PasswordsNotMatchException(String message) {
        super(message);
    }
}
