package com.ann.sokol.controller.page.path;

public class PageURI {

    public static String CATALOG__SAVE_TO_BASKET = "/catalog/saveToBasket";

    public static String BASKET = "/basket";

    public static String ACCOUNT = "/account";

    public static String CATALOG = "/catalog";

    public static String LOGIN = "/login";

    public static String LOGOUT = "/logout";

    public static String CATALOG__SORT = "/catalog/sort";

    public static String REGISTRATION = "/registration";

    public static String ADMIN__USERS = "/admin/users";

    public static String ADMIN__PRODUCT_MANAGEMENT = "/admin/productManagement";

    public static String ADMIN__USER__ORDERS = "/admin/user/orders";

    public static String FAVICON_ICO = "/favicon.ico";

}
